#include <iostream>
using namespace std;

double luasPermukaan(double diameter) {
    double r = diameter / 2;
    return 4 * 3.14 * r * r;
}

double volumeBola(double diameter) {
    double r = diameter / 2;
    return (4.0/3.0) * 3.14 * r * r * r;
}

double kelilingBola(double diameter) {
    return 3.14 * diameter;
}

int main() {
    int pilihan;
    char ulang;
    double diameter, jari, hasil;
    
    do {
        cout << "=========================================" << endl;
        cout << "Menghitung Bangun Datar Bola" << endl;
        cout << "=========================================" << endl;
        cout << "1. Luas Permukaan Bola" << endl;
        cout << "2. Volume Bola" << endl;
        cout << "3. Keliling Bola" << endl;
        cout << "=========================================" << endl;
        cout << "Pilih Menu: ";
        cin >> pilihan;
        
        switch(pilihan) {
            case 1:
                cout << "=========================================" << endl;
                cout << "Menu Luas Permukaan Bola" << endl;
                cout << "Input diameter = ";
                cin >> diameter;
                jari = diameter / 2;
                hasil = luasPermukaan(diameter);
                cout << "Hasil hitung jari-jari = " << jari << endl;
                cout << "Luas permukaan bola = " << hasil << endl;
                break;
                
            case 2:
                cout << "=========================================" << endl;
                cout << "Menu Volume Bola" << endl;
                cout << "Input diameter = ";
                cin >> diameter;
                jari = diameter / 2;
                hasil = volumeBola(diameter);
                cout << "Hasil hitung jari-jari = " << jari << endl;
                cout << "Volume bola = " << hasil << endl;
                break;
                
            case 3:
                cout << "=========================================" << endl;
                cout << "Menu Keliling" << endl;
                cout << "Input diameter = ";
                cin >> diameter;
                jari = diameter / 2;
                hasil = kelilingBola(diameter);
                cout << "Hasil hitung jari-jari = " << jari << endl;
                cout << "Keliling bola = " << hasil << endl;
                break;
                
            default:
                cout << "Menu Tidak Tersedia" << endl;
                break;
        }
        
        cout << "Apakah ingin mencoba lagi? (Y/N) ";
        cin >> ulang;
        
    } while (ulang == 'Y' || ulang == 'y');

    cout << "Program selesai. Terima kasih!\n";
}